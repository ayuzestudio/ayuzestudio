import brandMark from "@/assets/brand-mark.png";
import heroHome from "@/assets/hero-home.jpg";
import workWedding from "@/assets/work-wedding.jpg";
import workCorporate from "@/assets/work-corporate.jpg";
import workInterview from "@/assets/work-interview.jpg";
import svcVideography from "@/assets/svc-videography.jpg";
import svcLed from "@/assets/svc-led.jpg";
import svcProduction from "@/assets/svc-production.jpg";
import svcLivestream from "@/assets/svc-livestream.jpg";
import svcInterview from "@/assets/svc-interview.jpg";
import pWedding01 from "@/assets/p-wedding-01.jpg";
import pCorporate01 from "@/assets/p-corporate-01.jpg";
import pLed01 from "@/assets/p-led-01.jpg";
import pLivestream01 from "@/assets/p-livestream-01.jpg";
import pInterview01 from "@/assets/p-interview-01.jpg";
import pBrandFilms from "@/assets/p-brand-films.jpg";
import pConcertStream from "@/assets/p-concert-stream.jpg";
import pOnlocation from "@/assets/p-onlocation.jpg";
import pPanel from "@/assets/p-panel.jpg";
import pAwards from "@/assets/p-awards.jpg";
import pProcession from "@/assets/p-procession.jpg";
import pReception from "@/assets/p-reception.jpg";
import pBirthday from "@/assets/p-birthday.jpg";
import pPrivate from "@/assets/p-private.jpg";
import pSummitPhoto from "@/assets/p-summit-photo.jpg";
import pConferenceLed from "@/assets/p-conference-led.jpg";
import pLargeFormat from "@/assets/p-large-format.jpg";
import pVip from "@/assets/p-vip.jpg";
import pActivation from "@/assets/p-activation.jpg";
import pGalaLed from "@/assets/p-gala-led.jpg";
import heroLivestreaming from "@/assets/hero-livestreaming.jpg";
import heroInterviews from "@/assets/hero-interviews.jpg";
import gossipLiveLogo from "@/assets/gossip-live-logo.png";
import aboutTeam from "@/assets/about-team.jpg";
import founderPortrait from "@/assets/founder-portrait.jpg";

export const img = {
  brandMark,
  heroHome,
  workWedding,
  workCorporate,
  workInterview,
  svcVideography,
  svcLed,
  svcProduction,
  svcLivestream,
  svcInterview,
  pWedding01,
  pCorporate01,
  pLed01,
  pLivestream01,
  pInterview01,
  pBrandFilms,
  pConcertStream,
  pOnlocation,
  pPanel,
  pAwards,
  pProcession,
  pReception,
  pBirthday,
  pPrivate,
  pSummitPhoto,
  pConferenceLed,
  pLargeFormat,
  pVip,
  pActivation,
  pGalaLed,
  heroLivestreaming,
  heroInterviews,
  gossipLiveLogo,
  aboutTeam,
  founderPortrait,
} as const;
