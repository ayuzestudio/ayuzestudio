import type { ReactNode } from "react";
import { Reveal } from "./reveal";

export function CtaBanner({ heading, children }: { heading: string; children: ReactNode }) {
  return (
    <section className="page-wrap py-16 md:py-24">
      <Reveal>
        <div className="card-panel flex flex-wrap items-center justify-between gap-8 bg-gradient-to-br from-panel-2 to-panel p-8 md:p-12">
          <h2 className="max-w-[22ch] font-display text-2xl font-semibold text-foreground md:text-3xl">
            {heading}
          </h2>
          <div className="flex flex-wrap gap-4">{children}</div>
        </div>
      </Reveal>
    </section>
  );
}
