import { useState } from "react";
import type { FormEvent } from "react";

const WA_NUMBER = "2348112050470";
const EMAIL_ADDRESS = "Ayuzestudio1@gmail.com";

const SERVICES = [
  "Event Videography",
  "LED Screen Rental or Sale",
  "Video Production",
  "Livestreaming",
  "Interviews / Two-Person Conversation",
  "Not sure — need advice",
];

export function QuoteForm() {
  const [sent, setSent] = useState(false);
  const [links, setLinks] = useState({ wa: "#", email: "#" });

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = (data.get("name") || "").toString().trim();
    const service = (data.get("service") || "").toString().trim();
    const date = (data.get("date") || "").toString().trim();
    const phone = (data.get("phone") || "").toString().trim();
    const message = (data.get("message") || "").toString().trim();

    const lines = [
      "Hi AYUZE Studio, I'd like to request a quote.",
      name ? "Name: " + name : null,
      service ? "Service: " + service : null,
      date ? "Event date: " + date : null,
      phone ? "Phone/email: " + phone : null,
      message ? "Details: " + message : null,
    ].filter(Boolean) as string[];

    const plainText = lines.join("\n");
    const encoded = encodeURIComponent(plainText);
    const waUrl = `https://wa.me/${WA_NUMBER}?text=${encoded}`;
    const emailUrl = `mailto:${EMAIL_ADDRESS}?subject=${encodeURIComponent(
      "Quote Request" + (name ? " — " + name : "")
    )}&body=${encoded}`;

    setLinks({ wa: waUrl, email: emailUrl });
    setSent(true);
    requestAnimationFrame(() => {
      document.getElementById("quote-confirmation")?.focus();
    });
  };

  if (sent) {
    return (
      <div id="quote-confirmation" tabIndex={-1} className="card-panel p-8 text-center md:p-10">
        <div
          aria-hidden="true"
          className="mx-auto mb-5 grid h-14 w-14 place-items-center rounded-full border-[1.5px] border-amber bg-amber/10 text-2xl font-bold text-amber"
        >
          ✓
        </div>
        <h3 className="font-display text-xl font-semibold text-foreground">Thank you for reaching out to us.</h3>
        <p className="mx-auto mt-3 max-w-[42ch] text-sm leading-relaxed text-muted-foreground">
          Your request has been received successfully, and our team is looking forward to connecting with you.
          We&rsquo;ll review your message and get back to you shortly.
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <a className="btn btn-primary" href={links.wa} target="_blank" rel="noopener">
            Continue on WhatsApp
          </a>
          <a className="btn btn-ghost" href={links.email}>
            Continue by Email
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="card-panel p-7 md:p-9">
      <h2 className="font-display text-xl font-semibold text-foreground">Request a Quote</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        This sends your details to us on WhatsApp — no account or sign-up needed.
      </p>
      <form onSubmit={onSubmit} className="mt-7" noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="name" className="text-sm font-semibold text-foreground">Full name</label>
            <input id="name" name="name" type="text" required placeholder="e.g. Bisi Adewale" className="input-base" />
          </div>
          <div className="flex flex-col gap-1.5">
            <label htmlFor="phone" className="text-sm font-semibold text-foreground">Phone or email</label>
            <input id="phone" name="phone" type="text" required placeholder="e.g. 0803 123 4567" className="input-base" />
          </div>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="service" className="text-sm font-semibold text-foreground">Service needed</label>
            <select id="service" name="service" required className="input-base" defaultValue="">
              <option value="" disabled>
                Select a service
              </option>
              {SERVICES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label htmlFor="date" className="text-sm font-semibold text-foreground">Event date</label>
            <input id="date" name="date" type="date" className="input-base" />
            <span className="text-xs text-faint">Approximate is fine if not yet fixed.</span>
          </div>
        </div>
        <div className="mt-4 flex flex-col gap-1.5">
          <label htmlFor="message" className="text-sm font-semibold text-foreground">Tell us about the event</label>
          <textarea
            id="message"
            name="message"
            rows={5}
            placeholder="Venue, expected guests, and anything you already know you need (e.g. LED wall size, number of cameras)."
            className="input-base min-h-28 resize-y"
          />
        </div>
        <button type="submit" className="btn btn-primary mt-6 w-full">
          Send Request
        </button>
      </form>
    </div>
  );
}
