import { Link } from "@tanstack/react-router";
import { img } from "@/assets/images";

const socials = [
  {
    href: "https://www.instagram.com/ayuzestudio?stkn=ZHdzYXgwZ21xMWZWZp",
    label: "AYUZE Studio on Instagram",
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" strokeWidth="1.5" /><circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1.5" /><circle cx="17.2" cy="6.8" r="1" fill="currentColor" /></svg>
    ),
  },
  {
    href: "https://x.com/AyuzeStudio1",
    label: "AYUZE Studio on X",
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 5l14 14M19 5L5 19" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" /></svg>
    ),
  },
  {
    href: "https://www.facebook.com/share/1D7PAaX8dG/",
    label: "AYUZE Studio on Facebook",
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M14 9h2.5V6H14c-1.9 0-3.5 1.6-3.5 3.5V12H8v3h2.5v6H14v-6h2.3l.4-3H14V9.6c0-.3.3-.6.6-.6Z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" /></svg>
    ),
  },
  {
    href: "https://wa.me/2348112050470",
    label: "Chat with AYUZE Studio on WhatsApp",
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M20 12a8 8 0 1 1-3.7-6.7L20 4l-1 3.4A7.96 7.96 0 0 1 20 12Z" stroke="currentColor" strokeWidth="1.5" /><path d="M9 9.5c0 3 2.5 5.5 5.5 5.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
    ),
  },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-panel pb-8 pt-14">
      <div className="page-wrap">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Link to="/" className="inline-flex items-center gap-2.5 font-display text-lg font-bold text-foreground">
              <img src={img.brandMark} alt="" aria-hidden="true" className="brand-mark h-8 w-auto" />
              AYUZE STUDIO
            </Link>
            <p className="mt-4 max-w-[52ch] text-sm text-muted-foreground">
              A Lagos-based events media and technology company — videography, LED screens, video production,
              livestreaming and interviews, handled by one crew.
            </p>
            <div className="mt-5 flex gap-2.5">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  target="_blank"
                  rel="noopener"
                  className="grid h-9 w-9 place-items-center rounded-full border border-line text-muted-foreground transition-colors hover:border-amber hover:text-amber"
                >
                  {s.icon}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-faint">Navigate</h4>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/" className="text-muted-foreground transition-colors hover:text-amber">Home</Link></li>
              <li><Link to="/services" className="text-muted-foreground transition-colors hover:text-amber">Services</Link></li>
              <li><Link to="/work" className="text-muted-foreground transition-colors hover:text-amber">Work</Link></li>
              <li><Link to="/about" className="text-muted-foreground transition-colors hover:text-amber">About</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-faint">Services</h4>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/services" hash="videography" className="text-muted-foreground transition-colors hover:text-amber">Event Videography</Link></li>
              <li><Link to="/services" hash="led-screens" className="text-muted-foreground transition-colors hover:text-amber">LED Screens</Link></li>
              <li><Link to="/livestreaming" className="text-muted-foreground transition-colors hover:text-amber">Livestreaming</Link></li>
              <li><Link to="/interviews" className="text-muted-foreground transition-colors hover:text-amber">Interviews</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-faint">Contact</h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li>Oshodi, Lagos, Nigeria</li>
              <li><a href="tel:+2347067249970" className="transition-colors hover:text-amber">+234 706 724 9970</a></li>
              <li><a href="https://wa.me/2348112050470" target="_blank" rel="noopener" className="transition-colors hover:text-amber">WhatsApp: +234 811 205 0470</a></li>
              <li><a href="mailto:Ayuzestudio1@gmail.com" className="transition-colors hover:text-amber">Ayuzestudio1@gmail.com</a></li>
              <li><a href="https://share.google/9QxfqSynM4il6aknt" target="_blank" rel="noopener" className="transition-colors hover:text-amber">Google Business page</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-wrap justify-between gap-4 border-t border-border pt-6 text-sm text-faint">
          <span>© {new Date().getFullYear()} AYUZE Studio. All rights reserved.</span>
          <span>Oshodi, Lagos, Nigeria</span>
        </div>
      </div>
    </footer>
  );
}
