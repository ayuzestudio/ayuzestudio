import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { img } from "@/assets/images";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/work", label: "Work" },
  { to: "/livestreaming", label: "Livestreaming" },
  { to: "/interviews", label: "Interviews" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="page-wrap flex items-center justify-between py-4">
        <Link to="/" className="flex items-center gap-2.5 font-display text-lg font-bold tracking-tight text-foreground">
          <img src={img.brandMark} alt="" aria-hidden="true" className="brand-mark h-8 w-auto" />
          AYUZE STUDIO
        </Link>

        {/* Desktop nav */}
        <nav aria-label="Primary" className="hidden items-center gap-6 lg:flex">
          {NAV.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                aria-current={active ? "page" : undefined}
                className={`border-b-2 pb-0.5 text-[0.93rem] transition-colors ${
                  active
                    ? "border-signal text-foreground"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
          <Link to="/contact" className="btn btn-primary ml-1 !py-2.5">
            Get a Quote
          </Link>
        </nav>

        {/* Mobile toggle */}
        <button
          type="button"
          className="relative flex h-11 w-11 flex-col items-center justify-center gap-[6px] rounded-sm border border-line text-foreground lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label="Toggle menu"
          onClick={() => setOpen((v) => !v)}
        >
          <span
            className={`block h-0.5 w-5 bg-current transition-transform ${open ? "translate-y-[8px] rotate-45" : ""}`}
          />
          <span className={`block h-0.5 w-5 bg-current transition-opacity ${open ? "opacity-0" : ""}`} />
          <span
            className={`block h-0.5 w-5 bg-current transition-transform ${open ? "-translate-y-[8px] -rotate-45" : ""}`}
          />
        </button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="absolute inset-0 bg-black/60"
            aria-hidden="true"
            onClick={() => setOpen(false)}
          />
          <nav
            id="mobile-nav"
            aria-label="Primary mobile"
            className="absolute right-0 top-0 flex h-full w-[min(78vw,340px)] flex-col gap-1 border-l border-border bg-panel px-7 pb-8 pt-24"
          >
            {NAV.map((item) => {
              const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  aria-current={active ? "page" : undefined}
                  className={`w-full border-b border-border/60 py-3 text-lg ${
                    active ? "text-signal" : "text-foreground"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
            <Link to="/contact" className="btn btn-primary mt-5">
              Get a Quote
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
