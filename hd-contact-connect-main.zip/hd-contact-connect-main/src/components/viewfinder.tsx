import { cn } from "@/lib/utils";

type ViewfinderProps = {
  src: string;
  alt?: string;
  tag?: string;
  rec?: boolean;
  live?: boolean;
  timecode?: string;
  play?: boolean;
  aspect?: "4x3" | "16x9" | "1x1";
  className?: string;
};

const aspectClass = {
  "4x3": "aspect-[4/3]",
  "16x9": "aspect-video",
  "1x1": "aspect-square",
} as const;

export function Viewfinder({
  src,
  alt = "",
  tag,
  rec,
  live,
  timecode,
  play,
  aspect = "4x3",
  className,
}: ViewfinderProps) {
  return (
    <div className={cn("relative overflow-hidden rounded-md bg-panel-2", aspectClass[aspect], className)}>
      {/* corner brackets */}
      <span aria-hidden="true" className="absolute left-2.5 top-2.5 z-10 h-6 w-6 border-t-2 border-l-2 border-amber/90" />
      <span aria-hidden="true" className="absolute right-2.5 top-2.5 z-10 h-6 w-6 border-t-2 border-r-2 border-amber/90" />
      <span aria-hidden="true" className="absolute bottom-2.5 left-2.5 z-10 h-6 w-6 border-b-2 border-l-2 border-amber/90" />
      <span aria-hidden="true" className="absolute bottom-2.5 right-2.5 z-10 h-6 w-6 border-b-2 border-r-2 border-amber/90" />

      {tag && <span className="vf-chip left-11 top-2.5">{tag}</span>}
      {rec && (
        <span className="vf-chip right-11 top-2.5">
          <span className="rec-dot" aria-hidden="true" />
          REC
        </span>
      )}
      {live && !rec && (
        <span className="vf-chip left-11 top-2.5">
          <span className="rec-dot" aria-hidden="true" />
          LIVE
        </span>
      )}
      {timecode && <span className="vf-chip right-11 top-2.5">{timecode}</span>}

      <img src={src} alt={alt} loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/70"
      />
      {play && (
        <span
          aria-hidden="true"
          className="absolute left-1/2 top-[calc(50%-28px)] z-[2] grid h-14 w-14 -translate-x-1/2 place-items-center rounded-full border-2 border-white text-white"
        >
          ▶
        </span>
      )}
    </div>
  );
}
