import { Reveal } from "./reveal";

type WorkCardProps = {
  src?: string | undefined;
  alt?: string | undefined;
  tags: string[];
  title: string;
  blurb: string;
  play?: boolean | undefined;
  delay?: number | undefined;
};

export function WorkCard({ src, alt = "", tags, title, blurb, play, delay }: WorkCardProps) {
  return (
    <Reveal delay={delay} className="h-full">
      <article className="group flex h-full flex-col overflow-hidden rounded-md border border-border bg-panel transition-colors hover:border-amber/50">
        <div className="relative aspect-video overflow-hidden bg-panel-2">
          {src ? (
            <img
              src={src}
              alt={alt}
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
            />
          ) : (
            <div className="absolute inset-0 hero-glow" />
          )}
          {play && (
            <span
              aria-hidden="true"
              className="absolute left-1/2 top-[calc(50%-22px)] z-[2] grid h-11 w-11 -translate-x-1/2 place-items-center rounded-full border-2 border-white text-white/90 transition-transform duration-300 group-hover:scale-110"
            >
              ▶
            </span>
          )}
        </div>
        <div className="flex flex-1 flex-col p-5">
          <div className="mb-2.5 flex flex-wrap gap-1.5">
            {tags.map((t) => (
              <span key={t} className="tag-mono">{t}</span>
            ))}
          </div>
          <h3 className="font-display text-[1.05rem] font-semibold text-foreground">{title}</h3>
          <p className="mt-1.5 text-sm text-muted-foreground">{blurb}</p>
        </div>
      </article>
    </Reveal>
  );
}
