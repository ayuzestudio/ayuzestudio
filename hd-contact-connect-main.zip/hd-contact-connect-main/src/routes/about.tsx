import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Viewfinder } from "@/components/viewfinder";
import { CtaBanner } from "@/components/cta-banner";
import { Reveal } from "@/components/reveal";
import { img } from "@/assets/images";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — AYUZE Studio" },
      {
        name: "description",
        content:
          "AYUZE Studio is an events media and technology company in Oshodi, Lagos: fewer vendors, better coordination, our own equipment.",
      },
      { property: "og:title", content: "About — AYUZE Studio" },
      {
        property: "og:description",
        content: "A media crew built around one idea: fewer vendors, better coordination.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const PRINCIPLES = [
  ["One point of contact", "Whether it's cameras, screens or the stream, you brief one team and one team is accountable for the result."],
  ["Backup, always", "A second camera angle, a second internet connection, a second battery — the plan assumes something can fail."],
  ["Deliver on the date agreed", "Edits and stream recordings go out on the timeline we set at the brief, not \u201cwhenever it's ready.\u201d"],
];

const KIT = [
  ["Cameras", "Multi-camera 4K kits for events, interviews and production."],
  ["LED Screens", "Indoor & outdoor panels for stages, backdrops and signage."],
  ["Stream Gear", "Switchers, encoders and backup connectivity for live production."],
  ["Audio", "Lapel, boom and mixer setups for clean, broadcast-ready sound."],
];

function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="hero-glow">
          <div className="page-wrap py-16 md:py-24">
            <Reveal>
              <span className="eyebrow">ABOUT AYUZE STUDIO</span>
              <h1 className="mt-2 max-w-[22ch] font-display text-4xl font-semibold text-foreground md:text-5xl">
                A media crew built around one idea: fewer vendors, better coordination.
              </h1>
              <p className="mt-5 max-w-[62ch] text-lg text-muted-foreground">
                AYUZE Studio is an events media and technology company based in Oshodi, Lagos. We cover event
                videography, LED screens, video production, livestreaming and interviews — because most events need
                several of these at once, and coordinating separate vendors for each one is where things go wrong.
              </p>
            </Reveal>
          </div>
        </section>

        <section className="page-wrap grid items-center gap-12 py-16 md:py-24 lg:grid-cols-2">
          <Reveal>
            <span className="eyebrow">HOW WE STARTED</span>
            <h2 className="mt-2 font-display text-3xl font-semibold text-foreground md:text-4xl">
              Started around a camera, grew around the whole event.
            </h2>
            <p className="mt-4 max-w-[58ch] text-muted-foreground">
              AYUZE Studio began with event videography — covering weddings and corporate functions — and grew into
              LED screens, livestreaming and interview production as clients kept asking for more of their event's
              media to be handled by one team instead of three.
            </p>
          </Reveal>
          <Reveal delay={150}>
            <Viewfinder src={img.aboutTeam} tag="B-ROLL · TEAM" aspect="4x3" />
          </Reveal>
        </section>

        <section className="border-y border-border bg-panel/50 py-16 md:py-24">
          <div className="page-wrap">
            <Reveal>
              <span className="eyebrow">HOW WE WORK</span>
              <h2 className="mt-2 font-display text-3xl font-semibold text-foreground md:text-4xl">
                Three things we don't compromise on.
              </h2>
            </Reveal>
            <div className="mt-12 grid gap-6 md:grid-cols-3">
              {PRINCIPLES.map(([t, d], i) => (
                <Reveal key={t} delay={i * 80} className="h-full">
                  <article className="card-panel h-full p-7">
                    <span className="font-mono text-xs text-amber">0{i + 1}</span>
                    <h3 className="mt-3 font-display text-lg font-semibold text-foreground">{t}</h3>
                    <p className="mt-2 text-sm text-muted-foreground">{d}</p>
                  </article>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section className="page-wrap grid items-center gap-12 py-16 md:py-24 lg:grid-cols-[.8fr_1.2fr]">
          <Reveal>
            <Viewfinder src={img.founderPortrait} tag="PORTRAIT" aspect="1x1" />
          </Reveal>
          <Reveal delay={150}>
            <span className="eyebrow">FROM THE FOUNDER</span>
            <h2 className="mt-2 font-display text-3xl font-semibold text-foreground">A note from Ay.</h2>
            <blockquote className="mt-6 border-l-2 border-amber pl-6 font-display text-xl leading-relaxed text-foreground">
              "AyuzeStudio was built on a simple idea—when people trust us with their event, every detail should feel handled. From cameras and crew to LED screens and live streams, we plan every piece so you can focus on the moment. That's the foundation."
            </blockquote>
            <p className="mt-4 text-sm text-faint">— Ay, Founder, AYUZE Studio</p>
          </Reveal>
        </section>

        <section className="bg-paper py-16 text-paper-foreground md:py-24">
          <div className="page-wrap">
            <Reveal>
              <span className="eyebrow eyebrow--signal">CAPABILITY</span>
              <h2 className="mt-2 max-w-[26ch] font-display text-3xl font-semibold">
                Our own cameras, screens and stream gear — not rented last-minute.
              </h2>
              <p className="mt-4 max-w-[60ch] text-paper-muted">
                Owning our core equipment means we control quality end to end and can commit to dates with confidence,
                instead of depending on a rental house's availability.
              </p>
            </Reveal>
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {KIT.map(([t, d]) => (
                <div key={t} className="border-t border-current/20 pt-4">
                  <h3 className="font-semibold">{t}</h3>
                  <p className="mt-1 text-sm text-paper-muted">{d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <CtaBanner heading="Want to know if we're free on your date?">
          <Link to="/contact" className="btn btn-primary">Check Availability</Link>
        </CtaBanner>
      </main>
      <SiteFooter />
    </div>
  );
}
