import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { QuoteForm } from "@/components/quote-form";
import { Reveal } from "@/components/reveal";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — AYUZE Studio" },
      {
        name: "description",
        content:
          "Request a quote from AYUZE Studio in Oshodi, Lagos. Message us on WhatsApp, call, or email about videography, LED screens, livestreaming and interviews.",
      },
      { property: "og:title", content: "Contact Us — AYUZE Studio" },
      {
        property: "og:description",
        content: "Tell us about your event. We'll tell you what it needs.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

const DIRECT = [
  { label: "WHATSAPP", value: "+234 811 205 0470", href: "https://wa.me/2348112050470" },
  { label: "PHONE", value: "+234 706 724 9970", href: "tel:+2347067249970" },
  { label: "EMAIL", value: "Ayuzestudio1@gmail.com", href: "mailto:Ayuzestudio1@gmail.com" },
  { label: "LOCATION", value: "Oshodi, Lagos, Nigeria" },
  { label: "INSTAGRAM", value: "@ayuzestudio", href: "https://www.instagram.com/ayuzestudio" },
  { label: "X (TWITTER)", value: "@AyuzeStudio1", href: "https://x.com/AyuzeStudio1" },
  { label: "FACEBOOK", value: "AYUZE Studio", href: "https://www.facebook.com/ayuzestudio" },
  { label: "GOOGLE BUSINESS", value: "View our Google Business profile", href: "https://share.google/ayuzestudio" },
];

const FAQ = [
  ["How far in advance should I book?", "As early as possible for weddings and large events, especially for LED screens and livestreaming."],
  ["Do you travel outside Lagos?", "Yes, for most services."],
];

function ContactPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="hero-glow">
          <div className="page-wrap pb-8 pt-16 md:pt-20">
            <Reveal>
              <span className="eyebrow">CONTACT</span>
              <h1 className="mt-2 max-w-[20ch] font-display text-4xl font-semibold text-foreground md:text-5xl">
                Tell us about your event. We'll tell you what it needs.
              </h1>
              <p className="mt-5 max-w-[58ch] text-lg text-muted-foreground">
                Fill in the form and it opens a pre-filled WhatsApp message straight to our team, or reach us directly
                using the details on the right.
              </p>
            </Reveal>
          </div>
        </section>

        <section className="page-wrap grid items-start gap-10 py-12 md:py-16 lg:grid-cols-[1.3fr_1fr]">
          <Reveal>
            <QuoteForm />
          </Reveal>
          <Reveal delay={120} className="grid gap-6">
            <div className="card-panel p-7">
              <h2 className="font-display text-xl font-semibold text-foreground">Direct Contact</h2>
              <dl className="mt-5 grid gap-4">
                {DIRECT.map((d) => (
                  <div key={d.label} className="border-b border-line pb-4 last:border-0 last:pb-0">
                    <dt className="font-mono text-[0.7rem] tracking-widest text-faint">{d.label}</dt>
                    <dd className="mt-1">
                      {d.href ? (
                        <a
                          href={d.href}
                          target={d.href.startsWith("http") ? "_blank" : undefined}
                          rel="noopener noreferrer"
                          className="text-foreground transition-colors hover:text-amber"
                        >
                          {d.value}
                        </a>
                      ) : (
                        <span className="text-foreground">{d.value}</span>
                      )}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="card-panel p-7">
              <h2 className="font-display text-xl font-semibold text-foreground">Quick Answers</h2>
              <div className="mt-4 grid gap-2">
                {FAQ.map(([q, a]) => (
                  <details key={q} className="group border-b border-line py-3 last:border-0">
                    <summary className="cursor-pointer list-none font-semibold text-foreground marker:hidden">
                      <span className="mr-2 text-amber group-open:hidden">+</span>
                      <span className="mr-2 hidden text-amber group-open:inline">–</span>
                      {q}
                    </summary>
                    <p className="mt-2 text-sm text-muted-foreground">{a}</p>
                  </details>
                ))}
              </div>
            </div>
          </Reveal>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
