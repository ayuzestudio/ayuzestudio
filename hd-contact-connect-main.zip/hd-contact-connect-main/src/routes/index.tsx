import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Viewfinder } from "@/components/viewfinder";
import { WorkCard } from "@/components/work-card";
import { CtaBanner } from "@/components/cta-banner";
import { Reveal } from "@/components/reveal";
import { img } from "@/assets/images";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AYUZE Studio — Event Videography, LED Screens & Livestreaming in Lagos" },
      {
        name: "description",
        content:
          "AYUZE Studio is a Lagos-based events media and technology company: event videography, LED screen rental & sales, video production, livestreaming and interview production.",
      },
      {
        property: "og:title",
        content: "AYUZE Studio — Event Videography, LED Screens & Livestreaming",
      },
      {
        property: "og:description",
        content:
          "Lagos-based events media and technology company covering videography, LED screens, video production, livestreaming and interviews.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const SERVICES = [
  {
    title: "Event Videography",
    blurb:
      "Full coverage of weddings, corporate functions, concerts and private events — multi-camera capture, drone options and same-week highlight edits.",
    to: "/services",
    hash: "videography",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 7a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z" stroke="currentColor" strokeWidth="1.5" /><path d="m21 9-4 2.5L21 14V9Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" /></svg>
    ),
  },
  {
    title: "LED Screen Rental & Sales",
    blurb:
      "Indoor and outdoor LED walls for stages, backdrops and signage — rented for a single event or supplied and installed for permanent display.",
    to: "/services",
    hash: "led-screens",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="2.5" y="4" width="19" height="12" rx="1.2" stroke="currentColor" strokeWidth="1.5" /><path d="M8.5 20h7M12 16v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
    ),
  },
  {
    title: "Video Production",
    blurb:
      "Brand films, product promos, documentaries and social content — scripted, shot and edited to fit the platform they're built for.",
    to: "/services",
    hash: "video-production",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M4 6h16v9H4z" stroke="currentColor" strokeWidth="1.5" /><path d="M9 20h6M12 15v5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /><path d="m9 9 4 2.2L9 13.4V9Z" fill="currentColor" /></svg>
    ),
  },
  {
    title: "Livestreaming",
    blurb:
      "Multi-camera live production to YouTube, Facebook, Instagram and custom platforms — with an on-site engineer and a backup connection.",
    to: "/livestreaming",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3Z" stroke="currentColor" strokeWidth="1.5" /><path d="M6 11a6 6 0 0 0 12 0M12 19v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
    ),
  },
  {
    title: "Interviews & Two-Person Conversations",
    blurb:
      "Studio or on-location podcast-style interviews — two-shot and single-camera coverage, clean audio, and edits built for full episodes and clips.",
    to: "/interviews",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="8" cy="9" r="3" stroke="currentColor" strokeWidth="1.5" /><circle cx="17" cy="9" r="3" stroke="currentColor" strokeWidth="1.5" /><path d="M3 19c0-2.8 2.2-4.5 5-4.5s5 1.7 5 4.5M11 19c0-2.8 2.2-4.5 5-4.5s5 1.7 5 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
    ),
  },
];

const STATS = [
  { strong: "Videography", span: "Weddings, corporate, concerts" },
  { strong: "LED Screens", span: "Rental, sale & install" },
  { strong: "Livestreaming", span: "Multi-platform, multi-camera" },
  { strong: "Interviews", span: "Podcast-style conversations" },
];

function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* HERO */}
        <section className="hero-glow relative overflow-hidden">
          <div className="page-wrap grid items-center gap-12 py-16 md:py-24 lg:grid-cols-[1.1fr_.9fr]">
            <Reveal>
              <span className="eyebrow">ON AIR / LAGOS, NIGERIA</span>
              <h1 className="mt-2 max-w-[14ch] font-display text-4xl font-semibold leading-[1.05] text-foreground sm:text-5xl lg:text-6xl">
                We capture the moment your event goes live.
              </h1>
              <p className="mt-6 max-w-[52ch] text-lg text-muted-foreground">
                AYUZE Studio is a Lagos-based events media and technology company. We shoot it, screen it, stream it
                and edit it — weddings, conferences, concerts and conversations, handled by one crew from brief to
                delivery.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link to="/contact" className="btn btn-primary">Get a Quote</Link>
                <Link to="/work" className="btn btn-ghost">See Our Work</Link>
              </div>
              <div className="mt-10 flex flex-wrap gap-10">
                <div>
                  <strong className="block font-display text-2xl text-foreground">5</strong>
                  <span className="text-sm text-faint">Core services under one roof</span>
                </div>
                <div>
                  <strong className="block font-display text-2xl text-foreground">Lagos</strong>
                  <span className="text-sm text-faint">Based, travels nationwide</span>
                </div>
                <div>
                  <strong className="block font-display text-2xl text-foreground">1</strong>
                  <span className="text-sm text-faint">Crew, brief to delivery</span>
                </div>
              </div>
            </Reveal>
            <Reveal delay={150}>
              <Viewfinder src={img.heroHome} tag="CAM 01 · 4K" rec aspect="4x3" className="shadow-2xl shadow-black/40" />
            </Reveal>
          </div>
        </section>

        {/* STAT STRIP */}
        <section className="border-y border-border">
          <div className="page-wrap grid gap-6 py-9 sm:grid-cols-2 lg:grid-cols-4">
            {STATS.map((s, i) => (
              <Reveal key={s.strong} delay={i * 80}>
                <div>
                  <strong className="block font-display text-xl text-foreground md:text-2xl">{s.strong}</strong>
                  <span className="text-sm text-faint">{s.span}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* SERVICES OVERVIEW */}
        <section className="page-wrap py-16 md:py-24">
          <Reveal>
            <span className="eyebrow">WHAT WE DO</span>
            <h2 className="mt-2 max-w-[20ch] font-display text-3xl font-semibold text-foreground md:text-4xl">
              Five services. One crew. Zero handoffs.
            </h2>
            <p className="mt-4 max-w-[60ch] text-muted-foreground">
              Most events need more than one vendor — a camera crew, a screen supplier, a stream engineer. We built
              AYUZE Studio so you only have to brief one team.
            </p>
          </Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((s, i) => (
              <Reveal key={s.title} delay={i * 70} className="h-full">
                <article className="card-panel flex h-full flex-col gap-3.5 p-7 transition-colors hover:border-amber/40">
                  <span className="grid h-11 w-11 place-items-center rounded-sm border border-line text-amber">
                    {s.icon}
                  </span>
                  <h3 className="font-display text-lg font-semibold text-foreground">{s.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{s.blurb}</p>
                  <Link
                    to={s.to}
                    {...(s.hash ? { hash: s.hash } : {})}
                    className="mt-auto inline-flex items-center gap-1.5 text-sm font-semibold text-amber transition-colors hover:text-foreground"
                  >
                    Learn more <span aria-hidden="true" className="transition-transform group-hover:translate-x-0.5">›</span>
                  </Link>
                </article>
              </Reveal>
            ))}
            <Reveal delay={350} className="h-full">
              <article className="card-panel flex h-full flex-col gap-3.5 border-dashed p-7">
                <span className="grid h-11 w-11 place-items-center rounded-sm border border-line text-amber">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 4v16M4 12h16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
                </span>
                <h3 className="font-display text-lg font-semibold text-foreground">Not sure which fits?</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Most bookings combine two or three of these — a wedding with an LED welcome screen, or a livestreamed
                  conference with a two-person opening interview.
                </p>
                <Link
                  to="/contact"
                  className="mt-auto inline-flex items-center gap-1.5 text-sm font-semibold text-amber transition-colors hover:text-foreground"
                >
                  Talk to us <span aria-hidden="true">›</span>
                </Link>
              </article>
            </Reveal>
          </div>
        </section>

        {/* FEATURED WORK */}
        <section className="border-y border-border bg-panel/50 py-16 md:py-24">
          <div className="page-wrap">
            <Reveal>
              <span className="eyebrow">SELECTED WORK</span>
              <div className="mt-2 flex flex-wrap items-end justify-between gap-6">
                <h2 className="max-w-[20ch] font-display text-3xl font-semibold text-foreground md:text-4xl">
                  A few frames from recent projects.
                </h2>
                <Link to="/work" className="btn btn-ghost">View full portfolio</Link>
              </div>
            </Reveal>
            <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <WorkCard
                src={img.workWedding}
                alt="Wedding coverage"
                tags={["WEDDING", "MULTI-CAM"]}
                title="Wedding Coverage"
                blurb="Full-day multi-camera coverage with an LED backdrop option and a same-week highlight edit."
                play
              />
              <WorkCard
                src={img.workCorporate}
                alt="Corporate and conference coverage"
                tags={["LIVESTREAM", "CORPORATE"]}
                title="Corporate & Conference Coverage"
                blurb="Multi-camera livestream to YouTube with an in-room LED relay screen."
                play
              />
              <WorkCard
                src={img.workInterview}
                alt="Interview and conversation series"
                tags={["INTERVIEW", "STUDIO"]}
                title="Interview & Conversation Series"
                blurb="Two-person studio interviews, edited for full episodes and social clips — home of our own show, Gossip Live 24 Hours."
                play
              />
            </div>
          </div>
        </section>

        {/* PROCESS */}
        <section className="page-wrap py-16 md:py-24">
          <div className="grid items-start gap-12 lg:grid-cols-2">
            <Reveal>
              <span className="eyebrow">HOW WE WORK</span>
              <h2 className="mt-2 font-display text-3xl font-semibold text-foreground md:text-4xl">
                Brief to delivery, in four steps.
              </h2>
              <p className="mt-4 max-w-[60ch] text-muted-foreground">
                The same process runs underneath every service — whether it's a wedding, a livestream or a screen
                install.
              </p>
            </Reveal>
            <div>
              {[
                {
                  n: "01",
                  t: "Brief",
                  d: "You tell us the event, date, venue and what \u201cdone well\u201d looks like. We recommend the right mix of services.",
                },
                {
                  n: "02",
                  t: "Plan",
                  d: "We confirm crew size, equipment (cameras, screens, stream gear) and a shot list or run of show.",
                },
                {
                  n: "03",
                  t: "Produce",
                  d: "On the day, we shoot, stream and manage the screens — quietly, on time, without getting in the way of your event.",
                },
                {
                  n: "04",
                  t: "Deliver",
                  d: "You get edited footage, raw files where agreed, and stream recordings — on the timeline we agreed upfront.",
                },
              ].map((step, i) => (
                <Reveal key={step.n} delay={i * 80}>
                  <div className="relative flex gap-6 border-l border-line pb-8 pl-2 last:border-transparent last:pb-0">
                    <span className="absolute -left-[1.05rem] top-0 grid h-8 w-8 place-items-center rounded-full border-[1.5px] border-amber bg-background font-mono text-xs text-amber">
                      {step.n}
                    </span>
                    <div className="pl-10">
                      <h3 className="font-display text-lg font-semibold text-foreground">{step.t}</h3>
                      <p className="mt-1 text-sm text-muted-foreground">{step.d}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <div className="border-t border-border">
          <CtaBanner heading="Have an event on the calendar? Let's plan the coverage.">
            <Link to="/contact" className="btn btn-primary">Get a Quote</Link>
            <Link to="/services" className="btn btn-ghost">See All Services</Link>
          </CtaBanner>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
