import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Viewfinder } from "@/components/viewfinder";
import { CtaBanner } from "@/components/cta-banner";
import { Reveal } from "@/components/reveal";
import { img } from "@/assets/images";

export const Route = createFileRoute("/interviews")({
  head: () => ({
    meta: [
      { title: "Interviews & Conversations — AYUZE Studio" },
      {
        name: "description",
        content:
          "Podcast-style interviews and two-person conversations, produced properly in our Lagos studio or on location. Home of Gossip Live 24 Hours.",
      },
      { property: "og:title", content: "Interviews & Conversations — AYUZE Studio" },
      {
        property: "og:description",
        content: "Two mics, two angles, one conversation — studio, on-location and remote interview production.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: InterviewsPage,
});

const FORMATS = [
  ["Studio Conversation", "Host and guest seated together in a controlled setup — consistent lighting, backdrop and audio from episode to episode. Best for recurring interview series or podcasts."],
  ["On-Location Interview", "We bring lighting, audio and cameras to your guest — an office, a home, or an event floor. Best for founder profiles, vox pops and one-off features."],
  ["Remote / Hybrid Guest", "One speaker in-studio, one joining remotely, composited into a clean two-shot for the final edit. Best when a guest can't travel to Lagos."],
];

const INCLUDED = [
  "Two or more cameras: a wide two-shot plus individual angles on each speaker",
  "Lapel or boom microphones, recorded separately for a clean mix",
  "Three-point lighting set for studio sessions",
  "Full-episode edit with colour grading and audio mix",
  "Short vertical cutdowns for Instagram, TikTok and YouTube Shorts",
  "Captions/subtitles burned in for social clips",
  "Cover art and thumbnail frame for each episode",
  "Raw interview footage available on request",
];

function InterviewsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="hero-glow">
          <div className="page-wrap grid items-center gap-12 py-16 md:py-24 lg:grid-cols-2">
            <Reveal>
              <span className="eyebrow">TWO MICS, TWO ANGLES, ONE CONVERSATION</span>
              <h1 className="mt-2 max-w-[16ch] font-display text-4xl font-semibold text-foreground md:text-5xl">
                Conversations, produced properly.
              </h1>
              <p className="mt-5 max-w-[54ch] text-lg text-muted-foreground">
                Interviews and two-person conversations shot the way a real show is — a two-shot, individual angles on
                each speaker, boom or lapel audio, and lighting that doesn't wash anyone out. In our studio or wherever
                your guest is.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link to="/contact" className="btn btn-primary">Book an Episode</Link>
                <Link to="/work" className="btn btn-ghost">See Past Episodes</Link>
              </div>
            </Reveal>
            <Reveal delay={150}>
              <Viewfinder src={img.heroInterviews} tag="2-SHOT · STUDIO" rec aspect="4x3" />
            </Reveal>
          </div>
        </section>

        <section className="page-wrap py-16 md:py-24">
          <Reveal>
            <span className="eyebrow">FORMATS</span>
            <h2 className="mt-2 font-display text-3xl font-semibold text-foreground md:text-4xl">
              Three ways to run a conversation.
            </h2>
          </Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {FORMATS.map(([t, d], i) => (
              <Reveal key={t} delay={i * 80} className="h-full">
                <article className="card-panel h-full p-7">
                  <span className="font-mono text-xs text-amber">0{i + 1}</span>
                  <h3 className="mt-3 font-display text-lg font-semibold text-foreground">{t}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{d}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="border-y border-border bg-panel/50 py-16 md:py-24">
          <div className="page-wrap grid gap-12 lg:grid-cols-2">
            <Reveal>
              <span className="eyebrow">WHAT'S INCLUDED</span>
              <h2 className="mt-2 font-display text-3xl font-semibold text-foreground md:text-4xl">
                Every episode, produced the same way.
              </h2>
            </Reveal>
            <ul className="grid gap-3 text-muted-foreground">
              {INCLUDED.map((x) => (
                <li key={x} className="border-b border-line pb-3">— {x}</li>
              ))}
            </ul>
          </div>
        </section>

        <section className="page-wrap py-16 md:py-24">
          <Reveal>
            <div className="card-panel grid items-center gap-10 p-8 md:grid-cols-[200px_1fr] md:p-12">
              <img src={img.gossipLiveLogo} alt="Gossip Live 24 Hours logo" className="mx-auto w-40 md:w-full" loading="lazy" />
              <div>
                <span className="eyebrow eyebrow--signal">OUR OWN SHOW</span>
                <h2 className="mt-2 font-display text-3xl font-semibold text-foreground">Gossip Live 24 Hours</h2>
                <p className="mt-4 max-w-[60ch] text-muted-foreground">
                  Our in-house talk and interview show, produced start to finish inside AYUZE Studio — the same studio
                  conversation format described above, running as a recurring show rather than a one-off booking.
                </p>
                <div className="mt-6 flex flex-wrap gap-4">
                  <a href="https://www.instagram.com/ayuzestudio" target="_blank" rel="noopener noreferrer" className="btn btn-primary">Follow on Instagram</a>
                  <a href="mailto:Ayuzestudio1@gmail.com?subject=Gossip%20Live%2024%20Hours" className="btn btn-ghost">Email the Show</a>
                </div>
              </div>
            </div>
          </Reveal>
        </section>

        <CtaBanner heading="Have a guest and a topic? We'll handle the rest.">
          <Link to="/contact" className="btn btn-primary">Book an Episode</Link>
        </CtaBanner>
      </main>
      <SiteFooter />
    </div>
  );
}
