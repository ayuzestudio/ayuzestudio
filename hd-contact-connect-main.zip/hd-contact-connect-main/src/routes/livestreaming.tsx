import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Viewfinder } from "@/components/viewfinder";
import { CtaBanner } from "@/components/cta-banner";
import { Reveal } from "@/components/reveal";
import { img } from "@/assets/images";

export const Route = createFileRoute("/livestreaming")({
  head: () => ({
    meta: [
      { title: "Livestreaming in Lagos — AYUZE Studio" },
      {
        name: "description",
        content:
          "Multi-camera livestreams for conferences, weddings, church services and concerts — multi-platform, with backup connectivity and an on-site engineer.",
      },
      { property: "og:title", content: "Livestreaming in Lagos — AYUZE Studio" },
      {
        property: "og:description",
        content: "Go live everywhere, without a hitch: multi-camera, multi-platform livestreams with backup connectivity.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LivestreamingPage,
});

const FEATURES = [
  ["Multi-camera switching", "Two or more cameras cut live by an operator — wide, close and stage angles, switched in real time rather than fixed on one shot."],
  ["Multi-platform delivery", "Streamed to YouTube, Facebook, Instagram, Zoom or a custom RTMP destination — including sending to more than one platform at once."],
  ["Backup connectivity", "A secondary internet connection alongside the venue's network, so the stream survives a dropped connection instead of going dark."],
  ["On-site engineer", "Someone watching audio levels, stream health and viewer chat throughout — not a camera left running unattended."],
  ["Screen relay", "The same live feed can be pushed to an in-venue LED screen, so remote and in-room audiences see the same picture."],
  ["Recording & highlights", "A full recording of the stream, plus a short highlight cut for social media after the event ends."],
];

const USES = [
  ["Conferences & summits", "Multi-day programs streamed for delegates who couldn't travel."],
  ["Weddings", "For family and friends watching from abroad, live and on-time."],
  ["Church & faith services", "Weekly or one-off services streamed reliably, week after week."],
  ["Product launches", "Press and customers watching remotely, in full broadcast quality."],
  ["Concerts & ticketed shows", "Streams sold as paid virtual tickets alongside the in-person event."],
  ["Panel discussions", "Studio or venue panels streamed with clean multi-speaker audio."],
  ["Award ceremonies", "Long-form programs with graphics, replays and sponsor segments."],
  ["Training & workshops", "Sessions streamed to a private link for registered attendees only."],
];

const STEPS = [
  ["Scope the stream", "We confirm platforms, expected length, number of cameras and whether an LED relay screen is needed."],
  ["Venue & connectivity check", "We check the venue's internet and power, and plan a backup connection if needed."],
  ["Test stream", "Where possible, we run a short test stream ahead of the event to confirm platform settings and audio."],
  ["Go live", "Our engineer runs the stream from start to end, then hands over the recording and highlight clip."],
];

function LivestreamingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="hero-glow">
          <div className="page-wrap grid items-center gap-12 py-16 md:py-24 lg:grid-cols-2">
            <Reveal>
              <span className="eyebrow eyebrow--signal">LIVE IN 3 · 2 · 1</span>
              <h1 className="mt-2 max-w-[16ch] font-display text-4xl font-semibold text-foreground md:text-5xl">
                Go live, everywhere, without a hitch.
              </h1>
              <p className="mt-5 max-w-[54ch] text-lg text-muted-foreground">
                We run multi-camera livestreams for conferences, weddings, church services and concerts — switched
                live, streamed to the platforms your audience is already on, and backed up so a bad Wi-Fi day doesn't
                take you off air.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link to="/contact" className="btn btn-primary">Book a Livestream</Link>
                <Link to="/work" className="btn btn-ghost">See Streamed Events</Link>
              </div>
            </Reveal>
            <Reveal delay={150}>
              <Viewfinder src={img.heroLivestreaming} live timecode="00:42:18" aspect="4x3" />
            </Reveal>
          </div>
        </section>

        <section className="page-wrap py-16 md:py-24">
          <Reveal>
            <span className="eyebrow">WHAT'S INCLUDED</span>
            <h2 className="mt-2 max-w-[24ch] font-display text-3xl font-semibold text-foreground md:text-4xl">
              A stream that looks like a broadcast, not a phone on a stand.
            </h2>
          </Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map(([t, d], i) => (
              <Reveal key={t} delay={i * 60} className="h-full">
                <article className="card-panel h-full p-7">
                  <span className="font-mono text-xs text-amber">0{i + 1}</span>
                  <h3 className="mt-3 font-display text-lg font-semibold text-foreground">{t}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{d}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="border-y border-border bg-panel/50 py-16 md:py-24">
          <div className="page-wrap">
            <Reveal>
              <span className="eyebrow">WHO THIS IS FOR</span>
              <h2 className="mt-2 max-w-[24ch] font-display text-3xl font-semibold text-foreground md:text-4xl">
                Built for events where the room isn't the only audience.
              </h2>
            </Reveal>
            <div className="mt-12 grid gap-px overflow-hidden rounded-md border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
              {USES.map(([t, d]) => (
                <div key={t} className="bg-background p-6">
                  <h3 className="font-semibold text-foreground">{t}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground">{d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="page-wrap py-16 md:py-24">
          <div className="grid items-start gap-12 lg:grid-cols-2">
            <Reveal>
              <span className="eyebrow">BOOKING A LIVESTREAM</span>
              <h2 className="mt-2 font-display text-3xl font-semibold text-foreground md:text-4xl">
                What we need from you, and when.
              </h2>
              <p className="mt-4 max-w-[56ch] text-muted-foreground">
                The earlier we know the venue and internet situation, the fewer surprises on the day.
              </p>
            </Reveal>
            <ol className="grid gap-4">
              {STEPS.map(([t, d], i) => (
                <Reveal key={t} delay={i * 80}>
                  <li className="card-panel flex gap-5 p-6">
                    <span className="font-mono text-sm text-amber">0{i + 1}</span>
                    <div>
                      <h3 className="font-semibold text-foreground">{t}</h3>
                      <p className="mt-1 text-sm text-muted-foreground">{d}</p>
                    </div>
                  </li>
                </Reveal>
              ))}
            </ol>
          </div>
        </section>

        <CtaBanner heading="Have a date and a venue? Let's check the internet before anything else.">
          <Link to="/contact" className="btn btn-primary">Book a Livestream</Link>
        </CtaBanner>
      </main>
      <SiteFooter />
    </div>
  );
}
