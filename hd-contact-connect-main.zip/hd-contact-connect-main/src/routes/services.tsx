import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Viewfinder } from "@/components/viewfinder";
import { CtaBanner } from "@/components/cta-banner";
import { Reveal } from "@/components/reveal";
import { img } from "@/assets/images";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — AYUZE Studio" },
      {
        name: "description",
        content:
          "Event videography, LED screen rental & sales, video production, livestreaming and interviews in Lagos — five services under one crew.",
      },
      { property: "og:title", content: "Services — AYUZE Studio" },
      {
        property: "og:description",
        content:
          "Event videography, LED screen rental & sales, video production, livestreaming and interviews in Lagos — five services under one crew.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ServicesPage,
});

function IncludedList({ items }: { items: string[] }) {
  return (
    <ul className="mb-7 mt-6 grid gap-2 text-sm text-muted-foreground">
      {items.map((item) => (
        <li key={item}>— {item}</li>
      ))}
    </ul>
  );
}

function ServiceSplit({
  id,
  eyebrow,
  heading,
  body,
  items,
  image,
  imageTag,
  flip,
  panel,
  cta,
}: {
  id: string;
  eyebrow: string;
  heading: string;
  body: string;
  items: string[];
  image: string;
  imageTag: string;
  flip?: boolean;
  panel?: boolean;
  cta: { label: string; to: string };
}) {
  return (
    <section id={id} className={cn("py-16 md:py-24", panel && "bg-panel/50 border-y border-border")}>
      <div
        className={cn(
          "page-wrap grid items-center gap-12 lg:grid-cols-2",
          panel && "border-y-0"
        )}
      >
        <Reveal className={cn(flip && "lg:order-2")}>
          <Viewfinder src={image} tag={imageTag} aspect="4x3" />
        </Reveal>
        <Reveal delay={120} className={cn(flip && "lg:order-1")}>
          <span className="eyebrow">{eyebrow}</span>
          <h2 className="mt-2 max-w-[24ch] font-display text-2xl font-semibold text-foreground md:text-3xl">
            {heading}
          </h2>
          <p className="mt-4 max-w-[60ch] text-muted-foreground">{body}</p>
  {items.length > 0 && (
    <>
      <h3 className="mt-8 text-base font-semibold text-foreground">What's included</h3>
      <IncludedList items={items} />
    </>
  )}
  <Link to={cta.to} className="btn btn-primary self-start">{cta.label}</Link>
        </Reveal>
      </div>
    </section>
  );
}

function ServicesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="hero-glow">
          <div className="page-wrap py-16 md:py-20">
            <Reveal>
              <span className="eyebrow">SERVICES</span>
              <h1 className="mt-2 max-w-[18ch] font-display text-4xl font-semibold text-foreground md:text-5xl">
                Everything your event's media needs, under one crew.
              </h1>
              <p className="mt-5 max-w-[52ch] text-lg text-muted-foreground">
                Book one service or combine several — most events end up needing at least two.
              </p>
            </Reveal>
          </div>
        </section>

        <ServiceSplit
          id="videography"
          eyebrow="01 / EVENT VIDEOGRAPHY"
          heading="Coverage that doesn't miss the moment."
          body="Weddings, traditional ceremonies, corporate functions, concerts and private parties — we cover the moments that only happen once, from two or more angles, so nothing depends on a single camera being in the right place."
          items={[
            "Multi-camera coverage (ceremony, reception, key speeches)",
            "Optional drone footage for venue and crowd shots",
            "Same-week highlight edit, full-length edit delivered after",
            "Raw footage handover available on request",
          ]}
          image={img.svcVideography}
          imageTag="CAM 02 · 4K"
          cta={{ label: "Get a Quote", to: "/contact" }}
        />

        <ServiceSplit
          id="led-screens"
          eyebrow="02 / LED SCREEN RENTAL & SALES"
          heading="Big screens, done properly."
          body="Indoor and outdoor LED walls for stages, backdrops, welcome signage and live relay screens — supplied for a single event or sold and installed for permanent use."
          items={[
            "Indoor and outdoor panel options, sized to your stage or wall",
            "On-site technician for setup, content playback and teardown",
            "Live relay from our cameras straight to the screen",
            "Outright sale and permanent installation for venues and offices",
          ]}
          image={img.svcLed}
          imageTag="LED · OUTDOOR"
          flip
          panel
          cta={{ label: "Get a Quote", to: "/contact" }}
        />

        <ServiceSplit
          id="video-production"
          eyebrow="03 / VIDEO PRODUCTION"
          heading="Brand films, promos and content that's built for where it'll live."
          body="Product promos, brand documentaries, recruitment films and social-first content — scripted or unscripted, shot to match the platform it's going out on."
          items={[
            "Concept, scripting and shot planning",
            "Single or multi-day shoots, studio or on-location",
            "Colour-graded edit with sound design and captions",
            "Cutdowns sized for Instagram, YouTube and LinkedIn",
          ]}
          image={img.svcProduction}
          imageTag="CAM 01 · STUDIO"
          cta={{ label: "Get a Quote", to: "/contact" }}
        />

        <ServiceSplit
          id="livestreaming"
          eyebrow="04 / LIVESTREAMING"
          heading="Go live, without the risk."
          body="Multi-camera live production streamed to YouTube, Facebook, Instagram or a private link — with an on-site engineer and a backup internet connection, so the stream doesn't depend on the venue's Wi-Fi."
          items={[]}
          image={img.svcLivestream}
          imageTag="MULTI-CAM · LIVE"
          flip
          panel
          cta={{ label: "See Livestreaming in Detail", to: "/livestreaming" }}
        />

        <ServiceSplit
          id="interviews"
          eyebrow="05 / INTERVIEWS & TWO-PERSON CONVERSATIONS"
          heading="Conversations that look and sound like a real production."
          body="Podcast-style interviews and two-person conversations, filmed in-studio or on-location — clean audio, proper lighting, and a two-shot plus individual angles for a real edit, not a phone on a tripod."
          items={[]}
          image={img.svcInterview}
          imageTag="2-SHOT · STUDIO"
          cta={{ label: "See Interviews in Detail", to: "/interviews" }}
        />

        <section className="bg-paper py-16 text-paper-foreground md:py-24">
          <div className="page-wrap">
            <Reveal>
              <span className="eyebrow eyebrow--signal">CAPABILITY</span>
              <h2 className="mt-2 max-w-[22ch] font-display text-2xl font-semibold md:text-3xl">
                Built on our own equipment, not rented last-minute.
              </h2>
              <p className="mt-4 max-w-[56ch] text-paper-muted">
                We run our own cameras, LED panels, stream switchers and audio kit, which means fewer moving parts to
                coordinate and one team accountable for the whole day.
              </p>
            </Reveal>
          </div>
        </section>

        <CtaBanner heading="Tell us what you're planning — we'll tell you what it needs.">
          <Link to="/contact" className="btn btn-primary">Get a Quote</Link>
        </CtaBanner>
      </main>
      <SiteFooter />
    </div>
  );
}
