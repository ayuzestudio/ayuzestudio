import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { CtaBanner } from "@/components/cta-banner";
import { Reveal } from "@/components/reveal";
import { WorkCard } from "@/components/work-card";
import { img } from "@/assets/images";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/work")({
  head: () => ({
    meta: [
      { title: "Our Work — AYUZE Studio" },
      {
        name: "description",
        content:
          "A working selection of AYUZE Studio's weddings, corporate coverage, LED screens, livestreams, interviews and private party work in Lagos.",
      },
      { property: "og:title", content: "Our Work — AYUZE Studio" },
      {
        property: "og:description",
        content:
          "A working selection of AYUZE Studio's weddings, corporate coverage, LED screens, livestreams, interviews and private party work in Lagos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WorkPage,
});

type Category = "wedding" | "corporate" | "led" | "livestream" | "interview" | "party";

const FILTERS: { id: "all" | Category; label: string }[] = [
  { id: "all", label: "All Work" },
  { id: "wedding", label: "Weddings" },
  { id: "corporate", label: "Corporate" },
  { id: "led", label: "LED Screens" },
  { id: "livestream", label: "Livestreams" },
  { id: "interview", label: "Interviews" },
  { id: "party", label: "Private Parties" },
];

const PROJECTS: {
  category: Category;
  src?: string;
  tags: string[];
  title: string;
  blurb: string;
  play?: boolean;
}[] = [
  {
    category: "wedding",
    src: img.pWedding01,
    tags: ["WEDDING", "MULTI-CAM"],
    title: "Wedding Coverage",
    blurb: "Full-day multi-camera coverage, with an LED welcome screen option at the reception entrance.",
    play: true,
  },
  {
    category: "corporate",
    src: img.pCorporate01,
    tags: ["CORPORATE", "MULTI-CAM"],
    title: "Corporate & Conference Coverage",
    blurb: "Panel coverage and delegate interviews for multi-day conferences and summits.",
    play: true,
  },
  {
    category: "led",
    src: img.pLed01,
    tags: ["LED SCREEN", "OUTDOOR"],
    title: "LED Backdrops & Stage Walls",
    blurb: "Indoor and outdoor LED walls supplied, rigged and content-managed for stages and launches.",
  },
  {
    category: "livestream",
    src: img.pLivestream01,
    tags: ["LIVESTREAM", "MULTI-CAM"],
    title: "Livestream Production",
    blurb: "Multi-camera stream to YouTube and Facebook, with an in-venue LED relay option.",
    play: true,
  },
  {
    category: "interview",
    src: img.pInterview01,
    tags: ["INTERVIEW", "STUDIO"],
    title: "Interview & Conversation Series",
    blurb:
      "Two-person interview series shot in-studio, edited for YouTube and social clips — home of Gossip Live 24 Hours.",
    play: true,
  },
  {
    category: "wedding",
    src: img.svcVideography,
    tags: ["WEDDING", "TRADITIONAL"],
    title: "Traditional Ceremony Coverage",
    blurb: "Multi-camera coverage of traditional ceremonies, with optional drone establishing shots.",
  },
  {
    category: "corporate",
    src: img.pBrandFilms,
    tags: ["BRAND FILM", "SOCIAL-READY"],
    title: "Brand & Product Films",
    blurb: "Short brand documentaries and promos produced for internal, recruitment or social use.",
    play: true,
  },
  {
    category: "livestream",
    src: img.pConcertStream,
    tags: ["LIVESTREAM", "CONCERT"],
    title: "Concert & Ticketed Show Streams",
    blurb: "Stage LED wall paired with a multi-camera stream, ready to sell as a paid virtual ticket.",
    play: true,
  },
  {
    category: "interview",
    src: img.pOnlocation,
    tags: ["INTERVIEW", "ON-LOCATION"],
    title: "On-Location Interviews",
    blurb: "Short vox-pop style interviews recorded live at expos, launches and events.",
    play: true,
  },
  {
    category: "corporate",
    src: img.pPanel,
    tags: ["CORPORATE", "STAGE"],
    title: "Panel & Summit Coverage",
    blurb: "Full-stage photography and video coverage for panel discussions, summits and closing ceremonies.",
    play: true,
  },
  {
    category: "corporate",
    src: img.pAwards,
    tags: ["CORPORATE", "AWARDS"],
    title: "Awards & Recognition Events",
    blurb: "Formal photography for award ceremonies, gala nights and recognition dinners.",
  },
  {
    category: "wedding",
    src: img.pProcession,
    tags: ["WEDDING", "OUTDOOR"],
    title: "Wedding Party & Processions",
    blurb:
      "Candid coverage of the wedding party as they process, mingle and move between ceremony moments.",
  },
  {
    category: "wedding",
    src: img.pReception,
    tags: ["WEDDING", "RECEPTION"],
    title: "Reception & Grand Entrance Coverage",
    blurb:
      "Multi-camera coverage of the reception hall, grand entrance and first dance under full event lighting.",
    play: true,
  },
  {
    category: "party",
    src: img.pBirthday,
    tags: ["PRIVATE PARTY", "BIRTHDAY"],
    title: "Birthday & Milestone Celebrations",
    blurb:
      "Candid and directed coverage of birthdays and milestone celebrations, from cake-cutting to the dance floor.",
  },
  {
    category: "party",
    src: img.pPrivate,
    tags: ["PRIVATE PARTY", "BIRTHDAY"],
    title: "Private Celebrations",
    blurb: "Relaxed, guest-focused coverage for smaller private celebrations and get-togethers.",
  },
  {
    category: "corporate",
    src: img.pSummitPhoto,
    tags: ["CORPORATE", "SUMMIT"],
    title: "Summit & Delegate Photography",
    blurb: "On-stage group photography and audience coverage across multi-day industry summits.",
  },
  {
    category: "led",
    src: img.pConferenceLed,
    tags: ["LED SCREEN", "CONFERENCE"],
    title: "Conference Stage LED Walls",
    blurb: "Wide-format LED walls supplied and content-managed for multi-day industry conferences.",
  },
  {
    category: "led",
    src: img.pLargeFormat,
    tags: ["LED SCREEN", "CONCERT-SCALE"],
    title: "Large-Format Stage Production",
    blurb: "Full lighting truss, LED walls and multi-camera setup for concert-scale halls and arenas.",
    play: true,
  },
  {
    category: "corporate",
    src: img.pVip,
    tags: ["CORPORATE", "VIP"],
    title: "VIP & Dignitary Event Coverage",
    blurb: "Discreet, well-composed coverage for high-profile guests, receptions and photo-ops.",
  },
  {
    category: "corporate",
    src: img.pActivation,
    tags: ["BRAND ACTIVATION", "LIVE STAGE"],
    title: "Brand Activations & Market Events",
    blurb:
      "On-site video coverage of branded market activations, with live stage hosting segments and vendor floor footage.",
    play: true,
  },
  {
    category: "led",
    src: img.pGalaLed,
    tags: ["LED SCREEN", "GALA"],
    title: "Gala Dinner & Awards Night Backdrops",
    blurb:
      "Full-stage LED backdrops with custom motion content, rigged and run for black-tie dinners and award nights.",
  },
];

function WorkPage() {
  const [filter, setFilter] = useState<"all" | Category>("all");
  const visible = PROJECTS.filter((p) => filter === "all" || p.category === filter);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <section className="hero-glow">
          <div className="page-wrap pb-10 pt-16 md:pt-20">
            <Reveal>
              <span className="eyebrow">OUR WORK</span>
              <h1 className="mt-2 max-w-[20ch] font-display text-4xl font-semibold text-foreground md:text-5xl">
                A record of what we've shot, screened and streamed.
              </h1>
              <p className="mt-5 max-w-[52ch] text-lg text-muted-foreground">
                A working selection across formats. Filter by type, or get in touch to see a fuller reel for your
                category of event.
              </p>
              <div role="group" aria-label="Filter work by category" className="mt-9 flex flex-wrap gap-2.5">
                {FILTERS.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    aria-pressed={filter === f.id}
                    onClick={() => setFilter(f.id)}
                    className={cn(
                      "rounded-full border px-4 py-2 text-sm transition-colors",
                      filter === f.id
                        ? "border-signal bg-signal text-white"
                        : "border-line bg-transparent text-muted-foreground hover:border-amber hover:text-amber"
                    )}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        <section className="page-wrap pb-8 pt-4">
          {visible.length === 0 ? (
            <p className="py-16 text-center text-muted-foreground">Nothing in this category yet.</p>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {visible.map((p, i) => (
                <WorkCard
                  key={p.title}
                  src={p.src}
                  tags={p.tags}
                  title={p.title}
                  blurb={p.blurb}
                  play={p.play}
                  delay={(i % 3) * 70}
                />
              ))}
            </div>
          )}
        </section>

        <CtaBanner heading="Want to see a fuller reel for your type of event?">
          <Link to="/contact" className="btn btn-primary">Request Samples</Link>
        </CtaBanner>
      </main>
      <SiteFooter />
    </div>
  );
}
